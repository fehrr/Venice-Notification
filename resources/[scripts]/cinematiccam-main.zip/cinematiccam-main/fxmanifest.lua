fx_version 'bodacious'
games { 'gta5' }

author 'Kiminaze'

client_scripts {
	-- '@NativeUILua_Reloaded/src/NativeUIReloaded.lua',	
	"NativeUI.lua",
	'config.lua',
	'client.lua'
}

depedencies {
	"NativeUILua_Reloaded"
}
--server_script 'server.lua'
